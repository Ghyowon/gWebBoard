package com.javassem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.javassem.domain.BoardVO;
import com.javassem.service.BoardService;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@RequestMapping("/getBoardList.do")
	public void getBoardList(Model m) {
		m.addAttribute("boardList", boardService.getBoardList());
	}
	
	@RequestMapping("insertBoard.do")
	public void insertBoard(Model m) {
		
	}

	@RequestMapping("saveBoard.do")
	public String saveBoard(BoardVO vo) { //boardVO가 다 넘어온다
		boardService.insertBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	@RequestMapping("getBoard.do")
	public void getBoard(Model m, BoardVO vo) {
		m.addAttribute("board", boardService.getBoard(vo));
		//System.out.println(vo.getSeq());
	}
	
	@RequestMapping("updateBoard.do")
	public String updateBoard(BoardVO vo) {
		boardService.updateBoard(vo);
		return "redirect:getBoardList.do";
	}
	
	@RequestMapping("deleteBoard.do")
	public String deleteBoard(BoardVO vo) {
		boardService.deleteBoard(vo);
		return "redirect:getBoardList.do";
	}
	

}
